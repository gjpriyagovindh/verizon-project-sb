package com.enterprise;

public class EnterpriseConfig {

}
