package com.catalog;

public class CatalogConfigure {

}
