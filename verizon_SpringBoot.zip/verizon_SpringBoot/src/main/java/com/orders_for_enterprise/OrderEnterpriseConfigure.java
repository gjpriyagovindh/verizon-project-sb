package com.orders_for_enterprise;

public class OrderEnterpriseConfigure {

}
